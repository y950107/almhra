<?php

namespace App\Filament\Teacher\Widgets;

use App\Models\Candidate;
use App\Models\Halaka;
use App\Models\RecitationSession;
use App\Models\Student;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class Stateteacher extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            Stat::make('عدد الطلاب', function () {
                try {
                    return Student::whereHas('teacher.user', function ($query) {
                        $query->where('id', auth()->id());
                    })->count();
                } catch (\Exception $e) {
                    return 0;
                }
            })
                ->description('الطلاب تحت إشرافكم')
                ->descriptionIcon('icon-students')
                ->color('success')
                ->extraAttributes([
                    'class' => 'cursor-pointer',
                    'wire:click' => "\$dispatch('setStatusFilter', { filter: 'processed' })",
                ]),

            Stat::make('المترشحين المحالين الى مقابلة ', function () {
                try {
                    return candidate::where('evaluated', false)->whereHas('teacher.user', function ($query) {
                        return $query->where('id', auth()->id());
                    })->count();
                } catch (\Exception $e) {
                    return 0;
                }
            })
                ->description('مقابلات التقييم')
                ->descriptionIcon('icon-condidates')
                ->color('success')
                ->extraAttributes([
                    'class' => 'cursor-pointer',
                    'wire:click' => "\$dispatch('setStatusFilter', { filter: 'processed' })",
                ]),

            Stat::make('عدد الحلقات المفتوحة', function () {
                try {
                    return Halaka::whereHas('teacher.user', function ($query) {
                        $query->where('id', auth()->id());
                    })->count();
                } catch (\Exception $e) {
                    return 0;
                }
            })
                ->description('الحلقات المفتوحة')
                ->descriptionIcon('icon-sessions')
                ->color('warning')
                ->extraAttributes([
                    'class' => 'cursor-pointer',
                    'wire:click' => "\$dispatch('setStatusFilter', { filter: 'processed' })",
                ]),

            Stat::make('عدد الحصص المنجزة', function () {
                try {
                    return RecitationSession::whereHas('halaka.teacher.user', function ($query) {
                        $query->where('id', auth()->id());
                    })->count();
                } catch (\Exception $e) {
                    return 0;
                }
            })
                ->description('حصص التسميع')
                ->descriptionIcon('icon-reports')
                ->color('warning')
                ->extraAttributes([
                    'class' => 'cursor-pointer',
                    'wire:click' => "\$dispatch('setStatusFilter', { filter: 'processed' })",
                ]),
        ];
    }
}
