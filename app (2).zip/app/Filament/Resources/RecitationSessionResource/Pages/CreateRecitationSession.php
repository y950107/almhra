<?php

namespace App\Filament\Resources\RecitationSessionResource\Pages;

use App\Filament\Resources\RecitationSessionResource;
use Filament\Resources\Pages\CreateRecord;

class CreateRecitationSession extends CreateRecord
{
    protected static string $resource = RecitationSessionResource::class;
    // protected function mutateFormDataBeforeCreate(array $data): array
    // {
    //     dd($data);
    // }
}
