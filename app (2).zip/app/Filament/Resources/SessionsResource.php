<?php

namespace App\Filament\Resources;

use Filament\Forms;
use Filament\Tables;
use App\Models\Halaka;
use Filament\Forms\Form;
use Filament\Tables\Table;
use Filament\Resources\Resource;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Section;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DatePicker;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use App\Filament\Resources\SessionsResource\Pages;
use BezhanSalleh\FilamentShield\Contracts\HasShieldPermissions;
use IbrahimBougaoua\FilaProgress\Tables\Columns\CircleProgress;
use App\Filament\Resources\SessionsResource\RelationManagers\StudentsRelationManager;

class SessionsResource extends Resource implements HasShieldPermissions
{

    protected static ?string $model = Halaka::class;
    protected static ?string $navigationIcon = 'icon-sessions';
    public static function getNavigationLabel(): string
    {
        return __('filament.sessions.navigation_label');
    }

    public static function getModelLabel(): string
    {
        return __('filament.sessions.model_label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('filament.sessions.plural_model_label');
    }
    public static function getPermissionPrefixes(): array
    {
        return ['view', 'view_any', 'create', 'update', 'delete', 'delete_any', 'restore', 'force_delete'];
    }



    public static function form(Forms\Form $form): Forms\Form
    {
        return $form->schema([

            Section::make()
                ->columns(2)
                ->schema([
                    TextInput::make('name')
                        ->label('اسم الحلقة')
                        ->required(),

                    Select::make('teacher_id')
                        ->relationship('teacher', 'name')
                        ->label('المعلم')
                        ->preload()
                        ->searchable()
                        ->required(),

                    DatePicker::make('start_date')
                        ->label('تاريخ البداية')
                        ->required(),

                ])
        ]);
    }

    public static function table(Tables\Table $table): Tables\Table
    {
        return $table->columns([
            TextColumn::make('start_date')
                ->label('تاريخ البداية')
                ->date('d-m-Y')
                ->badge()
                ->color('info')
                ->sortable(),

            TextColumn::make('name')->label('اسم الحلقة')->sortable()->searchable(),

            TextColumn::make('teacher.name')->label('المعلم')->sortable(),




            TextColumn::make('students_count')
                ->label('عدد الطلاب')
                ->sortable()
                ->getStateUsing(fn(Halaka $record) => $record->students_count)
                ->badge()
                ->color('warning'),

                TextColumn::make('status')
                ->label('حالة الحلقة')
                ->formatStateUsing(fn($state) => $state === 'العدد مكتمل' ? 'التسجيل متاح' : 'التسجيل مفتوح')
                ->color(fn($state) => $state === 'العدد مكتمل' ? 'danger' : 'success'),

            CircleProgress::make('progress_percentage')->label('نسبة الإنجاز')
                ->getStateUsing(function ($record) {
                    $total = 100;
                    $progress = $record->getProgressPercentageAttribute();
                    return [
                        'total' => $total,
                        'progress' => $progress,
                    ];
                }),
        ])
            ->filters([
                Tables\Filters\SelectFilter::make('teacher_id')
                    ->label('المعلم')
                    ->relationship('teacher', 'name'),
            ])
            ->actions([
                EditAction::make(), //  `EditAction`
                DeleteAction::make()->visible(fn($record) => auth()->user()->can('delete', $record)),
            ])
            ->bulkActions([
                DeleteBulkAction::make(),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            StudentsRelationManager::class,
        ];
    }


    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSessions::route('/'),
            'create' => Pages\CreateSessions::route('/create'),
            'edit' => Pages\EditSessions::route('/{record}/edit'),
        ];
    }
}
