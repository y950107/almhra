<?php

namespace App\Filament\Resources;


use App\Filament\Resources\BannersResource\Pages;
use App\Models\banner;
use BezhanSalleh\FilamentShield\Contracts\HasShieldPermissions;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class BannersResource extends Resource implements HasShieldPermissions
{

    protected static ?string $model = banner::class;

    public static function getNavigationGroup(): ?string
    {
        return __('filament.grouplabel');
    }
    protected static ?string $navigationIcon = 'icon-banners';


    public static function getPermissionPrefixes(): array
    {
        return ['view', 'view_any', 'create', 'update', 'delete', 'delete_any'];
    }

    public static function getNavigationLabel(): string
    {
        return __('filament.banner.navigation_label');
    }
    public static function getModelLabel(): string
    {
        return __('filament.banner.model_label');
    }

    public static function getPluralModelLabel(): string
    {
        return __('filament.banner.plural_model_label');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('title')
                ->label('العنوان')
                ->maxLength(400)
                ->required(),

            TextInput::make('subtitle')
                ->label('العنوان الفرعي')
                ->nullable(),

            FileUpload::make('background')
                ->columnSpanFull()
                ->label('الخلفية')
                ->image()
                ->required(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('title')->label('العنوان')->searchable(),
            TextColumn::make('subtitle')->label('العنوان الفرعي')->searchable(),
            ImageColumn::make('background')->label('الخلفية'),
            TextColumn::make('created_at')->label('تاريخ الإنشاء')->date('Y-m-d'),
        ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListBanners::route('/'),
            'create' => Pages\CreateBanners::route('/create'),
            'edit' => Pages\EditBanners::route('/{record}/edit'),
        ];
    }
}
