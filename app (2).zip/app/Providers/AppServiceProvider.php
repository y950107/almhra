<?php

namespace App\Providers;

use App\Settings\GeneralSettings;
use BezhanSalleh\FilamentLanguageSwitch\LanguageSwitch;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {


    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {

        // dd(asset('storage/'.app(GeneralSettings::class)->logo));
        LanguageSwitch::configureUsing(function (LanguageSwitch $switch) {
            $switch
                ->locales(['ar', 'en']) // also accepts a closure
                ->visible(outsidePanels: true);
                /* ->outsidePanelRoutes([
                    'profile',
                    'home',

                ]); */
                /* ->flags([
                    'ar' => asset('flags/saudi-arabia.svg'),
                    'fr' => asset('flags/france.svg'),
                    'en' => asset('flags/usa.svg'),
                ]); */
        });






    }
}
