<footer class="main-footer">
	{{-- <div class="footer_bg-image" style="background-image: url({{asset('assets/images/background/footer-bg.jpg')}})"></div> --}}
	<div class="auto-container">
		<div class="inner-container">
			<!-- Widgets Section -->
		
		</div>
	</div>
	<div class="footer-bottom">
		<div class="footer_bottom-bg" style="background-image: url({{asset('assets/images/background/footer-bg_2.jpg')}})"></div>
		<div class="auto-container">
			<div class="d-flex flex-column flex-md-row justify-content-between align-items-center flex-wrap">
				<div class="copyright">جميع الحقوق محفوظة 2025  &copy; {{app(\App\Settings\GeneralSettings::class)->company_name}}</div>
				<ul class="footer-nav">
					<li><a href="#">سياسة الخصوصية</a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>